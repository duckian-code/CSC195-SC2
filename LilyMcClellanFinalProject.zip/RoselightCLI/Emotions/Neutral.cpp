//
// Created by anabelle on 05/06/25.
//

#include "Neutral.h"

void Neutral::SetContext(string input) {
    string context = "You are feeling neutral ! The user input is: " + input;
    finalContext = context;
}
